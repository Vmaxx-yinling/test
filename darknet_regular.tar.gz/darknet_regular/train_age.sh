./darknet classifier train /home/yinling/training/age_try/age.data /home/yinling/training/age_try/age_darknet19.cfg  cfg/darknet19.weights 2>&1 | tee 0426_age_darknet19.log
