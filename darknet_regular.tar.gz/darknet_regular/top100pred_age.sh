./classifier predict pred_age.data age2.cfg age2_.backup cfd_ali1207.list -out 0528_backup.log  | tee 2>&1 0528_backup_top100.log
