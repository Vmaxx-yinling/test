./darknet classifier predict cfg/imagenet1k.data cfg/extraction.cfg extraction.weights data/dog.jpg
malamute: 0.194782
Eskimo dog: 0.155007
Siberian husky: 0.143937
dogsled: 0.020943
miniature schnauzer: 0.020566

./darknet classifier predict cfg/imagenet1k.data cfg/extraction.cfg extraction.weights data/eagle.jpg
./darknet classifier predict cfg/imagenet1k.data cfg/extraction.cfg extraction.weights
./darknet classifier valid   cfg/imagenet1k.data cfg/extraction.cfg extraction.weights

./darknet classify cfg/tiny.cfg tiny.weights data/dog.jpg

./darknet classifier train cfg/cifar.data cfg/cifar_small.cfg
./darknet classifier train cfg/cifar.data cfg/cifar_small.cfg backup/cifar_small.backup


./darknet detect cfg/yolo.cfg yolo.weights data/dog.jpg
car: 54%
bicycle: 51%
dog: 56%

./darknet detector test cfg/coco.data cfg/yolo.cfg yolo.weights data/dog.jpg
./darknet detect cfg/yolo.cfg yolo.weights data/dog.jpg -thresh 0
./darknet detector test cfg/voc.data cfg/tiny-yolo-voc.cfg tiny-yolo-voc.weights data/dog.jpg
./darknet detector demo cfg/coco.data cfg/yolo.cfg yolo.weights
./darknet detector demo cfg/coco.data cfg/yolo.cfg yolo.weights <video file>
./darknet partial cfg/darknet19_448.cfg darknet19_448.weights darknet19_448.conv.23 23
./darknet detector train cfg/voc.data cfg/yolo-voc.cfg darknet19_448.conv.23
