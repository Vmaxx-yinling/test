./darknet classifier mttrain /home/yinling/car/training/multi_train.data  /home/yinling/car/training/multi.cfg  /home/yinling/car/darknet_mtcar/cfg/darknet19.weights
./darknet classifier mtpredlist  /home/yinling/car/training/multi_train.data  /home/yinling/car/training/multi.cfg  /home/yinling/car/darknet_mtcar/backup/0926/multi_3720.weights  /home/yinling/car/training/womanonly.list -out predlist.log
./darknet classifier mtpredsingle  /home/yinling/car/training/multi_train.data  /home/yinling/car/training/multi.cfg  /home/yinling/car/darknet_mtcar/backup/multi_12654.weights  
