#include "cost_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

COST_TYPE get_cost_type(char *s)
{
    if (strcmp(s, "seg")==0) return SEG;
    if (strcmp(s, "sse")==0) return SSE;
    if (strcmp(s, "masked")==0) return MASKED;
    if (strcmp(s, "smooth")==0) return SMOOTH;
    if (strcmp(s, "L1")==0) return L1;
    if (strcmp(s, "multisse")==0) return MULTISSE;
    fprintf(stderr, "Couldn't find cost type %s, going with SSE\n", s);
    return SSE;
}

char *get_cost_string(COST_TYPE a)
{
    switch(a){
        case SEG:
            return "seg";
        case SSE:
            return "sse";
        case MASKED:
            return "masked";
        case SMOOTH:
            return "smooth";
        case L1:
            return "L1";
        case MULTISSE:
            return "multisse";
    }
    return "sse";
}

cost_layer make_cost_layer(int batch, int inputs, COST_TYPE cost_type, float scale)
{
    fprintf(stderr, "cost                                           %4d\n",  inputs);
    cost_layer l = {0};
    l.type = COST;

    l.scale = scale;
    l.batch = batch;
    l.inputs = inputs;
    l.outputs = inputs;
    l.cost_type = cost_type;
    l.delta = calloc(inputs*batch, sizeof(float));
    l.output = calloc(inputs*batch, sizeof(float));
    l.cost = calloc(3, sizeof(float));
    //l.cost = calloc(1, sizeof(float));

    l.forward = forward_cost_layer;
    l.backward = backward_cost_layer;
    #ifdef GPU
    l.forward_gpu = forward_cost_layer_gpu;
    l.backward_gpu = backward_cost_layer_gpu;

    //l.delta_gpu = cuda_make_array(l.delta, inputs*batch);
    //l.output_gpu = cuda_make_array(l.output, inputs*batch);

    l.delta_gpu = cuda_make_array(l.output, inputs*batch);
    l.output_gpu = cuda_make_array(l.delta, inputs*batch);
    #endif
    return l;
}

void resize_cost_layer(cost_layer *l, int inputs)
{
    l->inputs = inputs;
    l->outputs = inputs;
    l->delta = realloc(l->delta, inputs*l->batch*sizeof(float));
    l->output = realloc(l->output, inputs*l->batch*sizeof(float));
#ifdef GPU
    cuda_free(l->delta_gpu);
    cuda_free(l->output_gpu);
    l->delta_gpu = cuda_make_array(l->delta, inputs*l->batch);
    l->output_gpu = cuda_make_array(l->output, inputs*l->batch);
#endif
}

void forward_cost_layer(cost_layer l, network net)
{
    if (!net.truth) return;
    if(l.cost_type == MASKED){
        int i;
        for(i = 0; i < l.batch*l.inputs; ++i){
            if(net.truth[i] == SECRET_NUM) net.input[i] = SECRET_NUM;
        }
    }

    if(l.cost_type == SMOOTH){
        smooth_l1_cpu(l.batch*l.inputs, net.input, net.truth, l.delta, l.output);
    }else if(l.cost_type == L1){
        l1_cpu(l.batch*l.inputs, net.input, net.truth, l.delta, l.output);
    }else if(l.cost_type == MULTISSE){
        multisse_cpu(l.batch*l.inputs, net.input, net.truth, l.delta, l.output);
        l.cost[1] = sum1_array(l.output, l.batch*l.inputs);
        l.cost[2] = sum2_array(l.output, l.batch*l.inputs);
        //l.cost[3] = sum3_array(l.output, l.batch*l.inputs);
        //l.cost[0] = l.cost[1]*10 + l.cost[2]*5 + l.cost[3]*.2; // need modify each cost's contribution.
        l.cost[0] = sum_array(l.output, l.batch*l.inputs);
        //printf("forward-cost0: %f cost1: %f cost2: %f cost3: %f\n", l.cost[0], l.cost[1], l.cost[2], l.cost[3]);
    }else {
        l2_cpu(l.batch*l.inputs, net.input, net.truth, l.delta, l.output);
    }

   /*
    printf("\n i net.input(pred) net.truth l.delta l.output\n");
    int i=0;
    for(i=0; i< l.batch*l.inputs;++i){
    	//int j = i+1;
    	printf("%d:  %f   %f   %f   %f\n", i, net.input[i], net.truth[i], l.delta[i], l.output[i]);
    	//printf("j%d:  %f   %f   %f   %f\n", j, net.input[j], net.truth[j], l.delta[j], l.output[j]);
    }
*/
 /*   int i=0;
    for(i=0; i< l.batch*l.inputs; i+=6){
        int j= i+1;
//      if(net.truth[i] == 0){
        if((!net.truth[i]) && (!net.truth[i+1])) {
        	printf("i%d:  %f   %f   %f  j%d:  %f   %f  %f\n", i, net.truth[i], l.delta[i], l.output[i], j, net.truth[j], l.delta[j], l.output[j]);
        	l.delta[i]=0;
            l.output[i]=0;
            l.delta[j]=0;
            l.output[j]=0;
            printf("i%d:  %f   %f   %f  j%d:  %f   %f  %f\n", i, net.truth[i], l.delta[i], l.output[i], j, net.truth[j], l.delta[j], l.output[j]);
            }
        }
*/
/*
    printf("\n i net.input(pred) net.truth l.delta l.output\n");
    int i=0 ;
    //int j;
    //for(i=0; i< l.batch*l.inputs;++i){
    for(i=0; i< l.inputs;++i){
    	int j=i%106+1;
    	printf("%d:  %f   %f   %f   %f\n", j, net.input[i], net.truth[i], l.delta[i], l.output[i]);
    }
*/

}



void backward_cost_layer(const cost_layer l, network net)
{
    axpy_cpu(l.batch*l.inputs, l.scale, l.delta, 1, net.delta, 1);
}

#ifdef GPU

void pull_cost_layer(cost_layer l)
{
    cuda_pull_array(l.delta_gpu, l.delta, l.batch*l.inputs);
}

void push_cost_layer(cost_layer l)
{
    cuda_push_array(l.delta_gpu, l.delta, l.batch*l.inputs);
}

int float_abs_compare (const void * a, const void * b)
{
    float fa = *(const float*) a;
    if(fa < 0) fa = -fa;
    float fb = *(const float*) b;
    if(fb < 0) fb = -fb;
    return (fa > fb) - (fa < fb);
}

void forward_cost_layer_gpu(cost_layer l, network net)
{
    if (!net.truth_gpu) return;
    if(l.smooth){
        scal_gpu(l.batch*l.inputs, (1-l.smooth), net.truth_gpu, 1);
        add_gpu(l.batch*l.inputs, l.smooth * 1./l.inputs, net.truth_gpu, 1);
    }
    if (l.cost_type == MASKED) {
        mask_gpu(l.batch*l.inputs, net.input_gpu, SECRET_NUM, net.truth_gpu);
    }

    if(l.cost_type == SMOOTH){
        smooth_l1_gpu(l.batch*l.inputs, net.input_gpu, net.truth_gpu, l.delta_gpu, l.output_gpu);
    } else if (l.cost_type == L1){
        l1_gpu(l.batch*l.inputs, net.input_gpu, net.truth_gpu, l.delta_gpu, l.output_gpu);
    } else if(l.cost_type == MULTISSE){
	    	float *input_cpu = calloc(l.inputs*l.batch, sizeof(float));
	    	cuda_pull_array(net.input_gpu, input_cpu, l.batch*l.inputs);
	    	float *truth_cpu = calloc(l.inputs*l.batch, sizeof(float));
	    	cuda_pull_array(net.truth_gpu, truth_cpu, l.batch*l.inputs);

	    	//multisse_cpu(l.batch*l.inputs, net.input, net.truth, l.delta, l.output);
	        //multisse_cpu(l.batch*l.inputs, net.input, truth_cpu, l.delta, l.output);
	    	multisse_cpu(l.batch*l.inputs, input_cpu, truth_cpu, l.delta, l.output);

	    	l.cost[1] = sum1_array(l.output, l.batch*l.inputs);
	    	l.cost[2] = sum2_array(l.output, l.batch*l.inputs);
	    	//l.cost[3] = sum3_array(l.output, l.batch*l.inputs);
	    	//l.cost[0] = l.cost[1]*10 + l.cost[2]*5 + l.cost[3]*.2; // need modify each cost's contribution.
	    	l.cost[0] = sum_array(l.output, l.batch*l.inputs);
	    	//printf("gpu-cost0: %f cost1: %f cost2: %f cost3: %f\n", l.cost[0], l.cost[1], l.cost[2], l.cost[3]);
/*
	    	//printf("\n i j net.input(pred) net.truth l.delta l.output\n");
	    	int i=0 ;
	    	//int j;
	    	for(i=0; i< l.batch*l.inputs;++i){
	    	//for(i=0; i< l.inputs;++i){
	    	     int j=i%106+1;
	    	     //printf("%d %d:  %f  %f  %f   %f  %f  %f\n", i, j, net.input[i], input_cpu[i], net.truth[i], truth_cpu[i], l.delta[i], l.output[i]);
	    	     }
*/
	    	cuda_push_array(l.delta_gpu, l.delta, l.batch*l.inputs);
	    	cuda_push_array(l.output_gpu, l.output, l.batch*l.inputs);
	    	free(input_cpu);
	    	free(truth_cpu);
	    }
    else {
        l2_gpu(l.batch*l.inputs, net.input_gpu, net.truth_gpu, l.delta_gpu, l.output_gpu);
    }

    if (l.cost_type == SEG && l.noobject_scale != 1) {
        scale_mask_gpu(l.batch*l.inputs, l.delta_gpu, 0, net.truth_gpu, l.noobject_scale);
        scale_mask_gpu(l.batch*l.inputs, l.output_gpu, 0, net.truth_gpu, l.noobject_scale);
    }

    if(l.ratio){
        cuda_pull_array(l.delta_gpu, l.delta, l.batch*l.inputs);
        qsort(l.delta, l.batch*l.inputs, sizeof(float), float_abs_compare);
        int n = (1-l.ratio) * l.batch*l.inputs;
        float thresh = l.delta[n];
        thresh = 0;
        printf("%f\n", thresh);
        supp_gpu(l.batch*l.inputs, thresh, l.delta_gpu, 1);
    }

    if(l.thresh){
        supp_gpu(l.batch*l.inputs, l.thresh*1./l.inputs, l.delta_gpu, 1);
    }

    //cuda_pull_array(l.output_gpu, l.output, l.batch*l.inputs); ----this two line need remove command if not use multisse cost  08/02/2017.
    //l.cost[0] = sum_array(l.output, l.batch*l.inputs);

}

void backward_cost_layer_gpu(const cost_layer l, network net)
{
    axpy_gpu(l.batch*l.inputs, l.scale, l.delta_gpu, 1, net.delta_gpu, 1);
}
#endif

