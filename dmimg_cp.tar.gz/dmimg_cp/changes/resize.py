import cv2
import numpy

img = cv2.imread("722126.jpg")
img_resize = cv2.resize(img,(130,140))
cv2.imwrite("722126_0.jpg",img_resize)

cv2.destroyAllWindows()